# API-league-of-legends
league of legends

## API-league-of-legends
Aplicacion desarrollada en javascript para obtener los personajes de league of legends.

## Pre-requisitos clipboard
Preinstalar:

- Visual code (https://code.visualstudio.com/).

## Construido con:
-  Html, Css, bootstrap, Javascript y mucho amor!

## Autores
Everto Farias

## Deploy
https://evertofd.github.io/API-league-of-legends/
